﻿// HomeController.cs
internal class BlogContext
{
}